package com.example.ejercicio3.network.responses

data class ExtendedIngredient(
        val aisle: String?,
        val amount: Double,
        val consistency: String?,
        val id: Int,
        val image: String?,
        val name: String?,
        val original: String?,
        val originalName: String?,
        val originalString: String?,
        val unit: String?)
